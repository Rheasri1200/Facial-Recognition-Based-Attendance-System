# face-recognnition Attendance system
## 1 Collecting Data:
Creating data with opencv 
training the data with face recognition library encoding face data to 128 array 
now storing these arrays in list and saving them with pickel 
## 2 Main
Now the stored pickle filemis used to mark live attendance of known person present infront of camera.
## GUI
Used python tkinter for providing GUI to our model.
